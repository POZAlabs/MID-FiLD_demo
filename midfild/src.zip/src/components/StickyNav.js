import React from 'react';


const StickyNav = ({ isVisible }) => {
  if (!isVisible) return null;

  return (
    <div className="sticky-nav">
      <button>Button 1</button>
      <button>Button 2</button>
      <button>Button 3</button>
    </div>
  );
};

export default StickyNav;
