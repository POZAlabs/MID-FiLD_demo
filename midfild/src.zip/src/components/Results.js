import React from 'react';

const Results = () => {
    return (
      <div id="Results" className='results-section'>
          <div>
            <h1>Results</h1>
            <div>
                <p> Results here </p>
          </div>
        </div>
      </div>
    );
}

export default Results;