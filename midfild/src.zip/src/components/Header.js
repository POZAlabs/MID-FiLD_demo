import React from 'react';

const Header = () => {
  const scrollToSection = (sectionId) => {
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div id="Header" className='header-section'>
      <h1> Mid-FiLD : MIDI Dataset for Fine-Level Dynamics </h1>
      <div className='nav'>
        <button onClick={() => scrollToSection("Intro")}>Intro</button>
        <button onClick={() => scrollToSection("Dataset")}>Dataset</button>
        <button onClick={() => scrollToSection("Results")}>Results</button>
      </div>
    </div>
  );
};

export default Header;
