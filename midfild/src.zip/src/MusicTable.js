import React from 'react';

const musicData = [
  { instrument: 'Bassoon', trackRole: 'Main Melody', mood: 'Dreamy', minCC: 50, maxCC: 100, wavFile: 'bassoon.wav' },
  { instrument: 'Flute', trackRole: 'Sub Melody', mood: 'Relaxing', minCC: 42, maxCC: 56, wavFile: 'flute.wav' },
  { instrument: 'Sax', trackRole: 'Main Melody', mood: 'Groovy', minCC: 72, maxCC: 114, wavFile: 'sax.wav' },
  { instrument: 'String Double Bass', trackRole: 'Bass', mood: 'Sad', minCC: 0, maxCC: 85, wavFile: 'double-bass.wav' },
  { instrument: 'Trumpet', trackRole: 'Main Melody', mood: 'Inspiring', minCC: 63, maxCC: 99, wavFile: 'trumpet.wav' },
];

const MusicTable = () => {
  return (
    <table>
      <thead>
        <tr>
          <th>Instrument</th>
          <th>Track Role</th>
          <th>Mood</th>
          <th>Min CC#1</th>
          <th>Max CC#1</th>
        </tr>
      </thead>
      <tbody>
        {musicData.map((item, index) => (
          <React.Fragment key={index}>
            <tr>
              <td>{item.instrument}</td>
              <td>{item.trackRole}</td>
              <td>{item.mood}</td>
              <td>{item.minCC}</td>
              <td>{item.maxCC}</td>
            </tr>
            <tr>
              <td colSpan="5" className='wav-file'>
                <audio controls>
                  <source src={`../assets/examples/${item.wavFile}`} type="audio/wav" />
                  Your browser does not support the audio element.
                </audio>
              </td>
            </tr>
          </React.Fragment>
        ))}
      </tbody>
    </table>
  );
};

export default MusicTable;
