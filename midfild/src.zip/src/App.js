import React, { useState, useEffect } from 'react';
import Intro from "./components/Intro";
import Dataset from "./components/Dataset";
import Results from "./components/Results";
import Header from "./components/Header";
import StickyNav from './components/StickyNav';

function App() {
  const [isStickyNavVisible, setStickyNavVisible] = useState(false);

  useEffect(() => {
    const checkHeaderAndSetListener = () => {
      const headerEl = document.querySelector('header');
      if (headerEl) {
        const headerHeight = headerEl.offsetHeight;
  
        const scrollListener = () => {
          const shouldBeVisible = window.scrollY > headerHeight;
          setStickyNavVisible(shouldBeVisible);
        };
  
        window.addEventListener('scroll', scrollListener);
        return () => window.removeEventListener('scroll', scrollListener);
      } else {
        console.error('No header found in DOM');
      }
    };
  
    // Initial check
    checkHeaderAndSetListener();
  
    // No cleanup needed here as it's handled in the checkHeaderAndSetListener function
  }, []);

  return (
    <div className="App">
      <Header />
      <section id="Intro">
        <Intro />
      </section>
      <section id="Dataset">
        <Dataset />
      </section>
      <section id="Results">
        <Results />
      </section>
      <StickyNav isVisible={isStickyNavVisible} />
    </div>
  );
}

export default App;
